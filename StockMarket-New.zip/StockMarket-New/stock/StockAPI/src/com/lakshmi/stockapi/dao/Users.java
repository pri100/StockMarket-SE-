package com.lakshmi.stockapi.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lakshmi.stockapi.utils.DataStore;


/**
 * Servlet implementation class Purchase
 */
@WebServlet("/users")
public class Users extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public Users() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Connection conn = DataStore.getConnection();
            Statement statement = conn.createStatement();
            String symbol = request.getParameter("username");
            System.out.println(symbol);
            
            String price = request.getParameter("price");
            String qty = request.getParameter("qty");
            String amt = request.getParameter("amt");
            statement.executeUpdate("insert into purchase (`uid`,`stock_symbol`,`qty`,`price`,`amt`)	VALUES "
                    + "(1111,'" + symbol + "','" + qty + "','" + price + "','" + (amt) + "')");
            statement.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        response.sendRedirect(request.getContextPath() + "/index.jsp");
    }
}

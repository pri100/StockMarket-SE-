package com.lakshmi.stockapi.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import javax.faces.context.FacesContext;

import com.lakshmi.stockapi.utils.DataStore;

public class LoginDAO {

    public static String[][] validate(String username, String password) {
        Connection con = null;
        PreparedStatement ps = null;

        try {
            con = DataStore.getConnection();
            ps = con.prepareStatement("select * from users where username = ? and password = ?");
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("username", rs.getString("username"));
                FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("role", rs.getString("role"));
                FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("uid", rs.getString("uid"));
                String[][] ud = {{rs.getString("username"),rs.getString("role")}};
                try{
                    if(rs.getBoolean("is_approved")){
                    	DataStore.Close(con);
                        return ud;
                    }else{
                    	return null;
                    }
                }catch(Exception e){
                	return null;
                }
                
            }

        } catch (SQLException e) {
            System.out.println("Login Error: " + e.getMessage());
            return null;
        } finally {

        }
        return null;
    }

}

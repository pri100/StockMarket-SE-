package com.lakshmi.stockapi.bean;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import com.lakshmi.stockapi.dao.LoginDAO;
import com.lakshmi.stockapi.utils.DataStore;
import com.lakshmi.stockapi.utils.UserRole;

@ManagedBean
@SessionScoped
public class LoginBean {

    private String username;
    private String password;
    
    
    

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String validateUser(String Username, String Password) {
		String[][] UserDetails = LoginDAO.validate(Username, Password);
        if (UserDetails != null) {
        	String role = UserDetails[0][1];
        	if(role.equals("Admin")){
                return "adminhome?faces-redirect=true";
        	}else if(role.equals("Manager")){
                return "userhome?faces-redirect=true";
        	}else if(role.equals("User")){
                return "userhome?faces-redirect=true";
        	}else{
        		FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_WARN, "Invalid Role.",""));
        		return "index";
        	}
        } else {
        	FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_WARN, "Invalid Username or Password",""));
        	FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_WARN, "You're registration may not be approved!",""));
            
            return "index";
        }
    }

    public String logout() throws IOException {
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        return "index.xhtml?faces-redirect=true";
    }
}

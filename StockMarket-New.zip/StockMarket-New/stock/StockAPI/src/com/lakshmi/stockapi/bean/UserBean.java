package com.lakshmi.stockapi.bean;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.el.ELContext;
import javax.el.MethodExpression;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.component.html.HtmlCommandButton;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import com.lakshmi.stockapi.dao.LoginDAO;
import com.lakshmi.stockapi.utils.DataStore;
import com.lakshmi.stockapi.utils.UserRole;

@ManagedBean
@SessionScoped
public class UserBean {

	private Integer Id;
	private String fname;
	private String lname;
	private String address;
	private String phone;
	private String email;
    private String nusername;
    private String password;
    private UserRole role;
    private Double amount;
    
    private String uRole;
    
    
    private void makenone() {
    	this.fname = "";
    	this.lname = "";
    	this.address = "";
    	this.phone = "";
    	this.email = "";
    	this.nusername = "";
    	this.password = "";
    	this.role = null;
    	this.amount = null;
    }
    
    
    public Integer getId() {
		return Id;
	}


	public void setId(Integer id) {
		Id = id;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public String getuRole() {
		return uRole;
	}


	public void setuRole(String uRole) {
		this.uRole = uRole;
	}


	public List<SelectItem> userRoles() {
    	List<SelectItem> roles = new ArrayList<>();
    	for(UserRole s : UserRole.values()) {
    		roles.add(new SelectItem(s.toString(),s.toString()));
    	}
    	return roles;
    }
	

    public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNusername() {
		return nusername;
	}


	public void setNusername(String nusername) {
		this.nusername = nusername;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserRole getRole() {
		return role;
	}

	public void setRole(UserRole role) {
		this.role = role;
	}

	public String GetUserList() {
		StringBuilder sb = new StringBuilder();
		Connection con = DataStore.getConnection();
		Statement statement;
		sb.append("<table class='table table-hover'>");
		sb.append("<thead><tr><th>Username</th><th>Name</th><th>Address</th><th>Phone</th><th>Email</th><th>Role</th><th>Amount</th></tr></thead>");
		sb.append("<tbody>");
		try {
			statement = con.createStatement();
			ResultSet rs = statement.executeQuery("select firstname, lastname, address, phonenumber, email, username, role, amount from users");
			while(rs.next()) {
				sb.append("<tr>");
				sb.append("<td>"+ rs.getString(1) + " " + rs.getString(2) +"</td>");
				sb.append("<td>"+ rs.getString(3) + "</td>");
				sb.append("<td>"+ rs.getString(4) + "</td>");
				sb.append("<td>"+ rs.getString(5) + "</td>");
				sb.append("<td>"+ rs.getString(6) + "</td>");
				sb.append("<td>"+ rs.getString(7) + "</td>");
				sb.append("<td>$"+ rs.getString(8) + "</td>");
				sb.append("</tr>");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		sb.append("</tbody></table>");
		
		
		return sb.toString();
	}
	
	public List<UserBean> InitApprovals(){
		StringBuilder sb = new StringBuilder();
		List<UserBean> users = new ArrayList<>();
		UserBean user;
		Connection con = DataStore.getConnection();
		Statement statement;
		try {
			statement = con.createStatement();
			ResultSet rs = statement.executeQuery("select uid, firstname, lastname, address, phonenumber, email, username, role, amount from users where is_approved is NULL");
			while(rs.next()) {
				user = new UserBean();
				user.setNusername(rs.getString("username"));
				user.setFname(rs.getString("firstname"));
				user.setLname(rs.getString("lastname"));
				user.setPhone(rs.getString("phonenumber"));
				user.setEmail(rs.getString("email"));
				user.setuRole(rs.getString("role"));
				user.setId(rs.getInt("uid"));
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return users;
	}
	
	public String approve(Integer id){
		Connection conn = DataStore.getConnection();
        
        try {
			PreparedStatement ps = conn.prepareStatement("update users set is_approved = 1 where uid = ?");
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
        return "adminhome";
	}
	
	public String decline(Integer id){
		Connection conn = DataStore.getConnection();
        
        try {
			PreparedStatement ps = conn.prepareStatement("update users set is_approved = 0 where uid = ?");
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
        return "adminhome";
	}
	
	public String createDbRecord(String fname, String lname, String address, String phone, String email, String username, String password) {
        try {

            Connection conn = DataStore.getConnection();
            
            PreparedStatement ps = conn.prepareStatement("INSERT INTO users (firstname, lastname, address, phonenumber, email, username, password, role, amount)"
            		+ "VALUES(?,?,?,?,?,?,?,?,?)");
            ps.setString(1, fname);
            ps.setString(2, lname);
            ps.setString(3, address);
            ps.setString(4, phone);
            ps.setString(5, email);
            ps.setString(6, username);
            ps.setString(7, password);
            if(this.uRole != null && !this.uRole.equals(""))
            	ps.setString(8, this.uRole);
            else
            	ps.setString(8, "User");
            ps.setDouble(9, 10000);
            ps.executeUpdate();
            
            this.makenone();
            
            ps.close();
            conn.close();
            FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO, "User Created Successfully",""));
        } catch (SQLException e) {
        	System.out.println(e);
            e.printStackTrace();
        }
        return "users";
    }
	
	public String updateUser(Integer Id, String fname, String lname, String address, String phone, String email, String password) {
        try {
        	boolean pass = (password != null && !password.trim().equals(""));
            Connection conn = DataStore.getConnection();
            StringBuilder sql = new StringBuilder("update users set "
            		+ "firstname = ?, lastname = ?, address = ?, phonenumber=?, email=? ");
            if(pass){
            	sql.append(", password=? ");
            }
            sql.append(" where uid=?");
            
            PreparedStatement ps = conn.prepareStatement(sql.toString());
            ps.setString(1, fname);
            ps.setString(2, lname);
            ps.setString(3, address);
            ps.setString(4, phone);
            ps.setString(5, email);
            if(pass){
            	ps.setString(6, password);
                ps.setInt(7, Id);
            }else{
                ps.setInt(6, Id);
            }
            
            ps.executeUpdate();
            
            this.makenone();
            
            ps.close();
            conn.close();
            FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO, "Profile updated Successfully",""));
        } catch (SQLException e) {
        	System.out.println(e);
            e.printStackTrace();
        }
        return "profile";
    }
	
	public UserBean getMyProfile(String Ids){
		Integer Id = Integer.parseInt(Ids);
		Connection conn = DataStore.getConnection();
        UserBean ub = new UserBean();
        try {
			PreparedStatement ps = conn.prepareStatement("select uid, username,firstname,lastname,address,phonenumber,email,amount from users where uid = ?");
			ps.setInt(1, Id);
			ResultSet rs = ps.executeQuery();
			rs.next();
			ub.setId(rs.getInt("uid"));
			ub.setNusername(rs.getString("username"));
			ub.setFname(rs.getString("firstname"));
			ub.setLname(rs.getString("lastname"));
			ub.setAddress(rs.getString("address"));
			ub.setPhone(rs.getString("phonenumber"));
			ub.setEmail(rs.getString("email"));
			ub.setAmount(rs.getDouble("amount"));
		} catch (SQLException e) {
			e.printStackTrace();
		}
        return ub;
	}


    public void logout() throws IOException {
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        FacesContext.getCurrentInstance().getExternalContext().redirect("index.xhtml");
    }
}

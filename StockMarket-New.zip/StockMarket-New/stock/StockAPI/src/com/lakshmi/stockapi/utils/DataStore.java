package com.lakshmi.stockapi.utils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

public final class DataStore {
	
	


    public static Connection getConnection() {
    	//Reading database.properties file
    	ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
    	Properties pr = new Properties();
    	try {
			System.out.println(ec.getApplicationContextPath());
			pr.load(ec.getResourceAsStream("/database.properties"));
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://" + pr.getProperty("db.host") + ":" + pr.getProperty("db.port") + "/" + pr.getProperty("db.dbname"), pr.getProperty("db.username"), pr.getProperty("db.password"));
            return conn;
        } catch (Exception e) {
            System.out.println("DB Exception: " + e.getMessage());
            return null;
        }
    }

    public static void Close(Connection conn) {
        try {
            conn.close();
        } catch (Exception e) {
        }
    }
}

package com.lakshmi.stockapi.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.faces.context.FacesContext;

import com.lakshmi.stockapi.utils.DataStore;

public class LoginDAO {

    public static boolean validate(String username, String password) {
        Connection con = null;
        PreparedStatement ps = null;

        try {
            con = DataStore.getConnection();
            ps = con.prepareStatement("select * from users where username = ? and password = ?");
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("username", rs.getString("username"));
                FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("role", rs.getString("role"));
                FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("uid", rs.getString("uid"));
                DataStore.Close(con);
                return true;
            }

        } catch (SQLException e) {
            System.out.println("Login Error: " + e.getMessage());
            return false;
        } finally {

        }
        return false;
    }

}

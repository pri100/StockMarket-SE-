package com.lakshmi.stockapi.utils;

public enum UserRole {

	Admin,Manager,User 
	
}
